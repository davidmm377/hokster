/*
 * mem_data.h
 *
 *  Created on: Feb 29, 2020
 *      Author: lukeb
 */

#ifndef SRC_MEM_DATA_H_
#define SRC_MEM_DATA_H_

#define MEM_LEN 18

uint8_t HOKSTER_MEMORY[MEM_LEN]= {
	0x00,
	0x00,
	0x00,
	0x00,
	0x00,
	0x00,
	0x00,
	0x00,
	0x00,
	0x00,
	0x00,
	0x00,
	0x00,
	0x00,
	0x00,
	0x00,
	27,
	36
};

#endif /* SRC_MEM_DATA_H_ */
